##################### Packages ###################
import torch
import torch.nn as nn
from torchvision import datasets
from torchvision import transforms
from torchvision.models import vit_b_32,resnet50
from torchvision.models import ViT_B_32_Weights, ResNet50_Weights
import time
import random as rd
from math import floor
import shutil
from PIL import Image
import os
from torch.utils.data import Dataset, DataLoader
from define_net import VGGnet, transform_vgg
import json
import math
import numpy as np
import cv2
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
########################################################
#################### Global Params #####################

step_num = 10
device = 'cpu'
if torch.cuda.is_available():
    device = "cuda:2"

log_en = True


cifar_dataset = datasets.CIFAR10(
    root='./data',
    train = True,
    transform=transform_vgg,
    download=True
)
root_path = "/data01/lzc/InterpretRes/"
###################################################################

def generate_spiral_matrix(n):
    matrix = [[0] * n for _ in range(n)]

    number = 1
    left, right, up, down = 0, n - 1, 0, n - 1
    while left < right and up < down:

        for i in range(left, right):
            matrix[up][i] = number
            number += 1

        for i in range(up, down):
            matrix[i][right] = number
            number += 1

        for i in range(right, left, -1):
            matrix[down][i] = number
            number += 1

        for i in range(down, up, -1):
            matrix[i][left] = number
            number += 1
        left += 1
        right -= 1
        up += 1
        down -= 1
    if n % 2 != 0: 
        matrix[n // 2][n // 2] = number
    return torch.tensor(matrix, dtype=torch.float32, device=device)

def generate_squre_matrix(N):
    matrix = [[0 for _ in range(N)] for _ in range(N)]
    center = (N-1) // 2
    value = 1
    radius = 0
    while radius <= center:
        for i in range(center - radius, center + radius + 1):
            matrix[center - radius][i] = value
            matrix[center + radius][i] = value
            matrix[i][center - radius] = value
            matrix[i][center + radius] = value
        radius += 1
        value += 1
    return torch.tensor(matrix).to(device).float()


def expand_dim(tensor:torch.Tensor, order:int):
    res = tensor.clone()
    for i in range(order):
        res = res.unsqueeze(-1)
    return res


def construct_masks(scores:torch.Tensor, maintain_rate, imp:bool):
    """
    scores:[B,C,H,W]
    imp == True means it is deleting important values
    """
    flatten_score = scores.view(scores.shape[0],-1)
    if maintain_rate == 1:
        mask = torch.zeros_like(scores).to(device).float()
        return mask
    thred_ind = math.floor(flatten_score.shape[-1]*maintain_rate)
    sorted_score, inds = torch.sort(flatten_score, dim=-1, descending=imp)
    if imp:
        thred_value = sorted_score[:,thred_ind]
        mask = expand_dim(thred_value, 3)
        mask = mask.repeat(1,3,32,32)
        mask = torch.where(scores >= mask, 0, 1)
        return mask
    else:
        thred_value = sorted_score[:,thred_ind]
        mask = expand_dim(thred_value, 3)
        mask = mask.repeat(1,3,32,32)
        mask = torch.where(scores <= mask, 0, 1)
        return mask


def del_elements_sort_freq(score:torch.Tensor,
                           pics:torch.Tensor,
                           imp:bool):
    steps = list(range(step_num))
    res_pic = pics.clone()
    for i in steps:
        ratio = i/10+0.1
        #scores = torch.abs(torch.fft.ifft2(scores))
        mask = construct_masks(score, ratio,imp)
        freqs = torch.fft.fftshift(pics)
        masked_pic = torch.fft.ifftshift(freqs*mask).real
        res_pic = torch.concat([res_pic, masked_pic], dim=0)
    return res_pic


def del_elements(scores:torch.Tensor, 
                 pics:torch.Tensor, 
                 imp:bool,
                 Freq:bool,
                 rand:bool):
    steps = list(range(step_num))
    res_pic = pics.clone()
    if Freq:
        for i in steps:
            if imp:
                ratio = i/10+0.1
            else:
                ratio = i/10+0.1
            #scores = torch.abs(torch.fft.ifft2(scores))
            mask = construct_masks(scores, ratio,imp)
            freqs = torch.fft.fft2(pics)
            masked_pic = torch.fft.ifft2(freqs*mask).real
            res_pic = torch.concat([res_pic, masked_pic], dim=0)
    else:
        scores = torch.abs(torch.fft.fft2(scores)).real
        freqs = torch.fft.fft2(pics)
        for i in steps:
            if imp:
                ratio = i/100+0.1
            else:
                ratio = i/100+0.1
            #mask = construct_masks(scores, ratio, imp)
            if rand is False:
                mask = construct_masks(scores, ratio,imp)
            else:
                mask = construct_masks(torch.rand_like(scores.real).to(device), ratio, imp)
            masked_pic = torch.fft.ifft2(freqs*mask).real
            res_pic = torch.concat([res_pic, masked_pic], dim=0)
    
    return res_pic


def get_change_rate(conf, bs):
    """
    conf:[B,1000*step]
    """
    rate = bs*torch.ones(step_num).float().to(device)
    ind = torch.arange(bs).to(device).long()
    base = torch.softmax(conf[:bs,:], dim=-1)
    pred_label = base.argmax(-1)
    base = base[ind,pred_label]
    for i in range(1,step_num):
        conf_step = torch.softmax(conf[bs*i:bs*(i+1),:], dim=-1)
        conf_step = conf_step[ind,pred_label]
        rate[i] = torch.sum(conf_step/base)
    
    return rate

def get_conf(pics:torch.Tensor, 
             model:nn.Module, 
             scores:torch.Tensor, 
             imp:bool,
             bs:int,
             Freq:bool,
             rand:bool):
    new_pics = del_elements(scores, pics, imp, Freq,rand)
    model.eval()
    conf = model(new_pics)
    return get_change_rate(conf, bs)


def print_info(msg, file_name = 'eval_ch_rate.log'):
    file_name = 'logs/'+file_name
    if log_en:
        f = open(file_name,'a')
        print(msg, file=f)
        f.close()
    else:
        print(msg)


def evaluate(model_name, method_name, imp, e, lr):
    res_path = root_path+method_name+"/"+model_name+"/"
    rep_time = 1
    bs = 1000

    val_loader = DataLoader(cifar_dataset,batch_size=bs,shuffle=False)
    rate = torch.zeros(rep_time,step_num).float().to(device)
    rand = False
    loss_final = [0,0,0]
    cn = 0
    score_list = [None, None, None]
    for batch,(X,y) in enumerate(val_loader):
        cn += 1
        if batch % 10 == 0:
            msg = "Method "+method_name+" "+str(batch) + " evaluating"
            print_info(msg)
        X = X.to(device)
        if method_name in ['fullgrad','inputgrad','smoothgrad','gradcam','smooth_grad','input_grad']:
            scores = torch.load(res_path+str(batch+1), map_location=device)
        elif method_name == 'random':
            scores = torch.rand_like(X).to(device)
            rand = True
        elif method_name == 'energy':
            scores = torch.abs(torch.fft.fft2(X))
        elif method_name == 'sort_freq':
            scores = generate_squre_matrix(32)
            scores = scores.unsqueeze(0).unsqueeze(0).repeat(X.shape[0],3,1,1)
        elif method_name =='ffc':
            with torch.enable_grad():
                for _ in range(rep_time):
                    scores, loss_t  = ffc(model_name, X, e, lr)
                    score_list[_] = scores.clone()
                    loss_final[_] += loss_t
        else:
            scores= torch.load(res_path+str(batch), map_location=device)
        
        if X.shape[0] != scores.shape[0]:
            msg = "Error in "+str(batch)
            print_info(msg)
            continue
        

        Freq = True
        if method_name == 'Freq' or method_name == 'energy':
            Freq = True
        for _ in range(rep_time):
            model = load_model()
            model.eval()
            rate[_] += get_conf(X,model,scores,imp,X.shape[0],Freq,rand)
        if batch % 10 == 0:
            msg = str(rate/((batch+1)*bs))
            print_info(msg)
            print(msg)
        torch.cuda.empty_cache()
    rate /= 50000
    rate = rate.cpu()
    rate = rate.numpy().tolist()
    for _ in range(rep_time):
        loss_final[_] /= cn
    msg = method_name+":"+model_name+":"+str(rate)+'\t Iter:'+str(e)+'\tLr:'+str(lr)+'\t Loss:'+str(loss_final)
    print_info(msg,'temp_ev_res.log')
    return rate


def ffc(model_name, 
                X:torch.Tensor, 
                e, 
                lr):
    X_ = X.clone()
    model_test = load_model()
    model_test.eval()
    X_.requires_grad = True
    loss_fn = torch.nn.CrossEntropyLoss()
    loss_final = 0
    with open('logs/loss.log','a') as f:
        print('-------',file=f)
        for i in range(e):
            X_.requires_grad = True
            model_test.to(device)
            pred = model_test(X_)
            pred_label = pred.argmax(-1)
            loss = loss_fn(pred, pred_label)
            loss.backward()
            print(loss.item(), e, file=f)
            X_grad = X_.grad.clone()
            X_.grad.zero_()
            with torch.no_grad():
                X_ = X_ - lr*X_grad
        loss_final = loss.item()
        with torch.no_grad():
            freqs = torch.fft.fft2(X)
            freq_after = torch.fft.fft2(X_)
            mag_ori = torch.abs(freqs)
            ori_after_mutual_energy = 2*(torch.conj(freq_after)*freqs).real
            scores = (ori_after_mutual_energy/(mag_ori)-mag_ori)
    return scores, loss_final


def load_model():
    model = VGGnet().to(device)
    model.load_state_dict(torch.load('model/vgg_net.pt',map_location=device))
    return model

def run():
    methods = ['sort_freq','energy']
    models = ['VGG']
    res_dict = {}
    for method in methods:
        res_dict[method] = {}
        for m in models:
            res_dict[method][m] = {}
            for imp in [False, True]:
                for e in [1]:
                    for lr in [1000]:
                        evaluate(m, method, imp, e, lr)

def main():
    with torch.no_grad():
        run()


if __name__ == "__main__":
    main()