##################### Packages ###################
import torch
import torch.nn as nn
from torchvision import datasets
from torchvision import transforms
from torchvision.models import resnet152, densenet201, inception_v3, vit_b_32,resnet50
from torchvision.models import ResNet152_Weights, DenseNet201_Weights, Inception_V3_Weights, ViT_B_32_Weights, ResNet50_Weights
import time
import random as rd
from math import floor
import shutil
from PIL import Image
import os
from torch.utils.data import Dataset, DataLoader
import json
import math
import numpy as np
import cv2
import matplotlib.pyplot as plt
import seaborn as sns
from define_net import ResNet18, VGGnet, transform_resnet, transform_vgg
########################################################
#################### Global Params #####################

step_num = 10
device = 'cpu'
if torch.cuda.is_available():
    device = "cuda:1"

log_en = True


class NormalizeInverse(transforms.Normalize):
    # Undo normalization on images

    def __init__(self, mean, std):
        mean = torch.as_tensor(mean)
        std = torch.as_tensor(std)
        std_inv = 1 / (std + 1e-7)
        mean_inv = -mean * std_inv
        super(NormalizeInverse, self).__init__(mean=mean_inv, std=std_inv)

    def __call__(self, tensor):
        return super(NormalizeInverse, self).__call__(tensor.clone())

normalize_fun = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225])

data_transform = transforms.Compose([
        transforms.Resize(224),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225])
    ])

unnormalize = NormalizeInverse(mean = [0.485, 0.456, 0.406],
                           std = [0.229, 0.224, 0.225])


methods_bs_dict = {'fullgrad':8,'Freq':128,
                   'random':16,'inputgrad':100,
                   'gradcam':100,'IG':4,
                   'smoothgrad':100}#,'energy':100,'sort_freq':128,'input_grad':128,'smooth_grad':128}
special_methods = {'input_grad':128,'smooth_grad':128}
focus_method = {'ffc':128}
done_method = ['Freq','inputgrad','gradcam','fullgrad','random']
root_path = "/data01/lzc/InterpretRes/"
sen_N = 10
###################################################################

def generate_noise_sample(sample:torch.Tensor):
    noise = torch.rand_like(sample, device=sample.device, dtype=sample.dtype)*0.4-0.2
    return noise+sample

def print_info(msg, file_name = 'eval_sens_local.log'):
    if log_en:
        f = open('logs/'+file_name,'a')
        print(msg, file=f)
        f.close()
    else:
        print(msg)


def sens_eval(model_name, method_name, imp, e):
    res_path = root_path+method_name+"/"+model_name+"/"
    if model_name == 'ResNet':
        val_dataset = datasets.CIFAR10(
            root='./data/',
            download=True,
            train=True,
            transform=transform_resnet)
    else:
        val_dataset = datasets.CIFAR10(
            root='./data/',
            download=True,
            train=True,
            transform=transform_vgg)
    bs = focus_method[method_name]
    #############
    #############
    val_loader = DataLoader(val_dataset,batch_size=bs,shuffle=False)
    rate = torch.zeros(step_num).float().to(device)
    rand = False
    time_sum = 0
    all_max_diff = 0
    for batch,(X,y) in enumerate(val_loader):
        
        if model_name == 'ResNet':
            model = ResNet18().to(device)
            model.load_state_dict(torch.load('model/resnet18.pt',map_location=device))
        else:
            model = VGGnet().to(device)
            model.load_state_dict(torch.load('model/vgg_net.pt',map_location=device))
        model.eval()
        with torch.enable_grad():
            original_score = ffc(model, X.to(device),1)
        original_score_norm = torch.linalg.norm(original_score.view(X.shape[0],-1),dim=-1)
        if torch.isinf(original_score_norm).sum()>0:
            print('')
        max_diff = -torch.inf*torch.ones(X.shape[0], device=device)
        for _ in range(sen_N):
            noised_data = generate_noise_sample(X.to(device))
            with torch.enable_grad():
                perturbed_score = ffc(model, noised_data, 1)
            perturbed_score_norm = torch.linalg.norm((perturbed_score-original_score).view(X.shape[0],-1),dim=-1)
            score_diff = perturbed_score_norm/original_score_norm
            max_diff = torch.where(max_diff>score_diff, max_diff, score_diff)
        # Due to the large scale of the score, it is prone to overflow. 
        # Therefore, we remove the individual values that have overflowed.
        all_max_diff += max_diff[torch.isnan(max_diff)==False].mean().item()

        if batch % 10 == 0:
            msg = str(all_max_diff/((batch+1)*bs))
            print_info(msg)

    diff = all_max_diff/(50000/bs)
    msg = method_name+":"+model_name+":"+str(diff)
    print_info(msg,'sens_temp_ev_res.log')
    return diff


def run():
    methods = focus_method.keys()
    models = ['VGG']
    res_dict = {}
    for method in methods:
        res_dict[method] = {}
        for m in models:
            """if m == 'ViT':
                continue"""
            if m == 'ViT' and method == 'fullgrad':
                continue
            #if method != 'sort_freq':
            #    continue
            res_dict[method][m] = {}
            sens_eval(m, method, None, None)


def ffc(model_test,X:torch.Tensor, e):
    X_ = X.clone()
    model_test.to(device)
    model_test.eval()
    loss_fn = torch.nn.CrossEntropyLoss()

    X_.requires_grad = True
    lr = 100

    for i in range(e):
        X_.requires_grad = True
        pred = model_test(X_)
        if i == 0:
            pred_label = pred.argmax(-1).detach()
        loss = loss_fn(pred, pred_label)
        loss.backward()
        X_grad = X_.grad.clone()

        X_.grad.zero_()
        with torch.no_grad():
            X_ = X_ - lr*X_grad
    with torch.no_grad():
        freqs = torch.fft.fft2(X)
        freq_after = torch.fft.fft2(X_)
        mag_ori = torch.abs(freqs)
        ori_after_mutual_energy = 2*(torch.conj(freq_after)*freqs).real

        scores = (ori_after_mutual_energy/(mag_ori)-mag_ori)
  
    del model_test, X_, X_grad
    torch.cuda.empty_cache()

    return scores


if __name__ == "__main__":
    with torch.no_grad():
        run()

